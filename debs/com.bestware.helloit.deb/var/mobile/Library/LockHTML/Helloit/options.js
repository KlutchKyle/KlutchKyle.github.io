var matchColor = true; // matchcolor with LS Wallpaper
var domatch = "Muted"; //Choose from Vibrant, LightVibrant, DarkVibrant, Muted, LightMuted, DarkMuted
var Clock = "12h";  //12h or 24h format clock