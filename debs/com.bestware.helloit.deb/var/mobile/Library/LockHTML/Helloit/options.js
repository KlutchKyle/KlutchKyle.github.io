var matchColor = true; // matchcolor with LS Wallpaper
var domatch = "DarkVibrant"; // Choose from Vibrant, LightVibrant, DarkVibrant, Muted, LightMuted, DarkMuted
var Clock = "12h"; // 12h or 24h format clock
var ct = "#00ff00"; // color of colored text
var pri = "こん"; 
var sec = "にちは"; 
