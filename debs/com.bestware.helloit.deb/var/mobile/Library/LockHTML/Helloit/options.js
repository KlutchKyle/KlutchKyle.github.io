var matchColor = true; // matchcolor with LS Wallpaper
var domatch = "LightVibrant"; //Choose from Vibrant, LightVibrant, DarkVibrant, Muted, LightMuted, DarkMuted
var Clock = "12h";  //12h or 24h format clock
var colour = "#00ff00"; //custom color for text
var colored = "H"; //colorized part of custom text
var uncolored = "ELLO"; //uncolorized part of custom text