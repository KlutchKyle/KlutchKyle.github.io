var blurRadius = 10; // Set blur Intensity  (COMING SOON!)
var blurRed = 255;  // Set blur Red Level when matchColor is false (RGB Values)
var blurGreen = 0; // Set blur Green Level when matchColor is false (RGB Values)
var blurBlue = 0; // Set blur Blue Level when matchColor is false (RGB Values)
var blurOpacity = 0.1; // Set blur opacity
var matchColor = true; // Wallpaper blur color matching toggle
var lightColor = true; // Match light color? Dark vibrant when false