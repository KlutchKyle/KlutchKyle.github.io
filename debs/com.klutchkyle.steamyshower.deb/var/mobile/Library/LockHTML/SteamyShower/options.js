var blurRadius = 10; // Set blur Intensity (COMING SOON!)
var blurRed = 255;  // Set blur Red Level (RGB Values)
var blurGreen = 255; // Set blur Green Level (RGB Values)
var blurBlue = 255; // Set blur Blue Level (RGB Values)
var blurOpacity = 0.05; // Set blur opacity
var matchColor = true; // Wallpaper blur color matching toggle
