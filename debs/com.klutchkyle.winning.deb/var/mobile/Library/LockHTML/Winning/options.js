var darkmode = true; // Toggle dark mode
var timeView = true; // Toggle time view
var dateView = true; // Toggle date view
var twelvehour = true; // Toggle 12 vs 24 hr time
var batteryView = true; // Toggle battery view (requires XenInfo)
var signalBarView = true; //Toggle signal view
var wifiView = true; //Toggle wifi view
var blur = false; //Blur the background
var batteryPercentView = false; //Show battery percent
var scaling = 1; // Rescale entire widget to your liking (ie: 1x = defualt or 2x = twice as big)
