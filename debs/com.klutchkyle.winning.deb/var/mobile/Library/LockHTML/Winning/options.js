var darkmode = false; // Toggle dark mode
var clock = true; // Show the clock
var date = true; // Show date
var twelvehour = false; // Toggle 12/24-hour clock
var battery = false; // Toggle battery view (requires InfoStats)
var wifi = true;
var fadein = true; //Fade in widget after locking your device 