var test = true; //no options with this version. Feel free to make suggestions! :)




