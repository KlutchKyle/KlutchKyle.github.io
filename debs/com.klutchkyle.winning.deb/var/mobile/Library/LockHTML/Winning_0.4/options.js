var twelvehour = false; // Toggle 12/24-hour clock



