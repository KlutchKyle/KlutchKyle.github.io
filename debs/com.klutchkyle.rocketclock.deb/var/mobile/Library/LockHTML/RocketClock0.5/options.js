var darkmode = false; // Toggle dark mode
var date = true; // Show date
var twelvehour = false;
var battery = false; // Toggle battery view (requires InfoStats)
var wifi = true;
