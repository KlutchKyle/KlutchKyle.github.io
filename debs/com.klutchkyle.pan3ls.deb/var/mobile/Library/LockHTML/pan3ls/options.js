var matchColor = true;
var twelvehour = false;
